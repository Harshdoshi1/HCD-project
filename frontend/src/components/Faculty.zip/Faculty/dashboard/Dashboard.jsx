import React from 'react';
import FacultyLayout from '../FacultyLayout';

const DashboardFaculty = () => {
    return <FacultyLayout />;
};

export default DashboardFaculty;
