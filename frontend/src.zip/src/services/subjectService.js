// import axios from 'axios';

// export const saveAssignedSubjects = async (assignmentData) => {
//   try {
//     const response = await axios.post('/api/subjects/assign', assignmentData);
//     return response.data;
//   } catch (error) {
//     console.error('Error saving subjects:', error);
//     throw error;
//   }
// };
