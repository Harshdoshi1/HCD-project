import React, { useState } from 'react';


const UpdateGrades = () => {
    return <>
        <h4>rfververfqervqrefe</h4>
    </>
};

export default UpdateGrades;