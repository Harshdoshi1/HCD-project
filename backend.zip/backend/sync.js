const { syncDB } = require('./models');

syncDB();
