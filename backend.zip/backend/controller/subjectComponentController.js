const UniqueSubDegree = require('../models/uniqueSubDegree');
const ComponentWeightage = require('../models/componentWeightage');
const ComponentMarks = require('../models/componentMarks');
const sequelize = require('../config/db');

// Add subject with components (weightage and marks)


