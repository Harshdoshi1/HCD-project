// const express = require("express");
// const router = express.Router();
// const {

//     addActivity,
//     updateActivity,
//     deleteActivity,
//     getextraStudentActivities,
//     getextraStudentActivitieswithenrollmentandSemester,

// } = require("../controller/studentExtracurricularController");

// // Add new activity
// router.post("/", addActivity);

// // Update existing activity
// router.put("/:id", updateActivity);

// // Delete activity
// router.delete("/:activityId", deleteActivity);

// router.post('/getextra', getextraStudentActivities);//update route

// router.post('/getExtraWithSem', getextraStudentActivitieswithenrollmentandSemester);

// module.exports = router;
